import { createClient } from "npm:@supabase/supabase-js@2";

// Admin-only staff management: create a staff account, reset a staff password, remove a user.
// Staff sign in with their staff code. Each code maps to a private login address that is never emailed.

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

const STAFF_ROLES = ["teacher", "accounts", "principal", "deputy", "admin"];
const staffEmail = (code: string) => `${code.toLowerCase()}@staff.nbva.invalid`;

function tempPassword(): string {
  const chars = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789";
  const bytes = crypto.getRandomValues(new Uint8Array(10));
  return Array.from(bytes, (b) => chars[b % chars.length]).join("") + "A1";
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const url = Deno.env.get("SUPABASE_URL")!;
    const anon = Deno.env.get("SUPABASE_ANON_KEY")!;
    const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const caller = createClient(url, anon, { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } });
    const { data: { user } } = await caller.auth.getUser();
    if (!user) return json({ error: "Not signed in" }, 401);

    const admin = createClient(url, service);
    const { data: me } = await admin.from("profiles").select("role").eq("id", user.id).single();
    if (me?.role !== "admin") return json({ error: "Only an admin can do this" }, 403);

    const body = await req.json();

    if (body.action === "create_staff") {
      const name = String(body.name ?? "").replace(/[<>&"]/g, "").trim();
      const role = String(body.role ?? "");
      let code = String(body.code ?? "").trim().toUpperCase();
      const password = String(body.password ?? "");
      if (!name) return json({ error: "Enter the full name" }, 400);
      if (!STAFF_ROLES.includes(role)) return json({ error: "Choose a staff role" }, 400);
      if (!code) {
        const prefix = { teacher: "TCH", accounts: "ACC", principal: "PRN", deputy: "DEP", admin: "ADM" }[role]!;
        const { count } = await admin.from("profiles").select("id", { count: "exact", head: true }).eq("role", role);
        let i = (count ?? 0) + 1;
        while (true) {
          code = prefix + String(i++).padStart(3, "0");
          const { data: taken } = await admin.from("profiles").select("id").eq("staff_code", code).maybeSingle();
          if (!taken) break;
        }
      }
      if (!/^[A-Z0-9-]{3,12}$/.test(code)) return json({ error: "The staff code must be 3 to 12 letters, numbers or hyphens" }, 400);
      if (password.length < 8) return json({ error: "The starting password needs at least 8 characters" }, 400);
      const { data: taken } = await admin.from("profiles").select("id").eq("staff_code", code).maybeSingle();
      if (taken) return json({ error: "That staff code is already in use" }, 400);

      const { data, error } = await admin.auth.admin.createUser({
        email: staffEmail(code),
        password,
        email_confirm: true,
        app_metadata: { role, staff_code: code, must_change_password: true },
        user_metadata: { full_name: name },
      });
      if (error) return json({ error: error.message }, 400);
      return json({ id: data.user.id, code, name, role });
    }

    if (body.action === "reset_password") {
      const { data: target } = await admin.from("profiles").select("id, role").eq("id", body.user_id).single();
      if (!target || target.role === "parent") return json({ error: "Choose a staff member" }, 400);
      const password = tempPassword();
      const { error } = await admin.auth.admin.updateUserById(target.id, { password });
      if (error) return json({ error: error.message }, 400);
      await admin.from("profiles").update({ must_change_password: true }).eq("id", target.id);
      return json({ password });
    }

    if (body.action === "delete_user") {
      if (body.user_id === user.id) return json({ error: "You cannot remove your own account" }, 400);
      const { data: target } = await admin.from("profiles").select("id, role").eq("id", body.user_id).single();
      if (!target) return json({ error: "User not found" }, 404);
      if (target.role === "admin") {
        const { count } = await admin.from("profiles").select("id", { count: "exact", head: true }).eq("role", "admin");
        if ((count ?? 0) < 2) return json({ error: "You cannot remove the last admin account" }, 400);
      }
      const { error } = await admin.auth.admin.deleteUser(target.id);
      if (error) return json({ error: error.message }, 400);
      return json({ ok: true });
    }

    return json({ error: "Unknown action" }, 400);
  } catch (e) {
    return json({ error: String((e as Error).message ?? e) }, 400);
  }
});
